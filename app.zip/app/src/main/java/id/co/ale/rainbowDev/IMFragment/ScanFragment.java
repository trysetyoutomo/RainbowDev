package id.co.ale.rainbowDev.IMFragment;

import android.app.Fragment;
import android.os.Bundle;

/**
 * Created by Alcatel-Dev on 01/11/2017.
 */

public class ScanFragment extends Fragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
